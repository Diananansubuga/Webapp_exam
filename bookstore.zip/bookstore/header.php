
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css"> <!-- Assuming this is your custom CSS file -->
        <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="./bootstrap/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="./bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="clear-fix pt-5 pb-3"></div>
    <nav class="navbar bg-warning">
        <div class="container">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <a class="navbar-brand" href="index.php">Online Book Store</a>
            </div>
            <div class="navbar-collapse">
                <ul class="nav">
                        <li class="nav-item"><a class="nav-link" href="admin_signout.php">Logout</a></li>
                        <li class="nav-item"><a class="nav-link" href="recomendations.php">Reccomendation</a></li>
                        <li class="nav-item"><a class="nav-link" href="books.php">Books</a></li>
                        <li class="nav-item"><a class="nav-link" href="cart.php">My Cart</a></li>
                        <li class="nav-item"><a class="nav-link" href="cart.php">About Us</a></li>
                        <li class="nav-item"><a class="nav-link" href="cart.php">Contact Us</a></li>
                        <div class="d-flex">
      <!-- Search Form in Navbar (visible on all screen sizes) -->
                        <form id="searchForm" class="mr-3">
                            <input type="text" id="search" name="search" placeholder="Search...">
                        </form>
                    
                </ul>
                <center>
                <!-- Empty div to display search results -->
                <div id="searchResults"></div>
                </center>
            </div>
        </div>
    </nav>

                <center>
                <!-- Empty div to display search results -->
                <div id="searchResults"></div>
                </center>

                <script src="script.js"></script>

    <?php if(isset($title) && $title == "Home"): ?>
        <div class="container">
            
            <center><h1>Welcome to Diana's Online Book Store</h1></center>
            <center><h6>Latest Additions<h6></center>
            <hr>
        </div>
    <?php endif; ?>

    <div class="container" id="main">
        <!-- Your content goes here -->
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="script.js"></script>
     <!-- Assuming this is your custom JavaScript file -->
</body>
</html>
