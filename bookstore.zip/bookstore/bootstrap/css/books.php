<?php
    include 'conn.php';
  session_start();
  
  $count = 0;
  // connecto database
  require_once "database_functions.php";
  $conn = db_connect();

  $query = "SELECT book_id, book_img,title FROM books";
  $result = mysqli_query($conn, $query);
  if(!$result){
    echo "Can't retrieve data " . mysqli_error($conn);
    exit;
  }

  $title = "List of Books";
  require_once "header.php";
?>
<div class="content">
  <div class="row">
    <?php
    // Query to fetch book details from the database
    $query = "SELECT * FROM books";
    $result = mysqli_query($connect, $query);

    if ($result && mysqli_num_rows($result) > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
        // Output each book as a card
       
        echo '<div class="col-md-4">';
        echo '<div class="card">';
        echo '<img src="' . $row["book_img"] . '" class="card-img-top" alt="Book Image">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title">' . $row["title"] . '</h5>';
        echo '<p class="card-text"><strong>Author:</strong> ' . $row["author"] . '</p>';
        echo '<p class="card-text"><strong>Genre:</strong> ' . $row["genre"] . '</p>';
        echo '<p class="card-text"><strong>Date Published:</strong> ' . $row["date_pub"] . '</p>';
        echo '<p class="card-text"><strong>Price:</strong> $' . $row["price"] . '</p>';
        
        echo '<a href="cart.php?id=' . $row["book_id"] . '" class="add-to-cart-btn">Add to Cart</a>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
      }
    } else {
      echo "No books found.";
    }
    ?>
    
<?php
      
  if(isset($conn)) { mysqli_close($conn); }
  require_once "footer.php";
?>