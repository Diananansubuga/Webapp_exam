<?php
include 'conn.php';
session_start();

$title = "Home";
require_once "header.php";
require_once "database_functions.php";

// Connect to the database
$conn = db_connect();

// Query to fetch the latest 4 books based on publication date
$query = "SELECT * FROM books ORDER BY date_pub DESC LIMIT 4";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    // Display each book as a card
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="col-md-4">';
        echo '<div class="card">';
        echo '<img src="' . $row["book_img"] . '" class="card-img-top" alt="Book Image">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title">' . $row["title"] . '</h5>';
        echo '<p class="card-text"><strong>Author:</strong> ' . $row["author"] . '</p>';
        echo '<p class="card-text"><strong>Genre:</strong> ' . $row["genre"] . '</p>';
        echo '<p class="card-text"><strong>Date Published:</strong> ' . $row["date_pub"] . '</p>';
        echo '<p class="card-text"><strong>Price:</strong> $' . $row["price"] . '</p>';
        echo '<a href="cart.php?id=' . $row["book_id"] . '" class="add-to-cart-btn">Add to Cart</a>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo "No books found.";
}

// Close database connection
if(isset($conn)) {
    mysqli_close($conn);
}

require_once "footer.php";
?>
