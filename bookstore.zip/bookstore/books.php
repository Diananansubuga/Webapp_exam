<?php
  session_start();
  $book_id = isset($_GET['book_id']) ? $_GET['book_id'] : '';
  $count = 0;
  // connect to database
  require_once "database_functions.php";
  $conn = db_connect();

  if ($book_id) {
    $query = "SELECT * FROM books WHERE book_id = $book_id";
  } else {
    $query = "SELECT * FROM books";
  }

  echo "<pre>$query</pre>"; // print out the SQL query for debugging

  $result = mysqli_query($conn, $query);
  if(!$result){
    echo "Can't retrieve data " . mysqli_error($conn);
    exit;
  }

  $title = "List of Books";
  require_once "header.php";
?>
  <p class="lead text-center text-muted">List of All Books</p>
    <?php for($i = 0; $i < mysqli_num_rows($result); $i++){ ?>
      <div class="row">
        <?php while($book = mysqli_fetch_assoc($result)){ ?>
          <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 py-2 mb-2">
      		<a href="book.php?book_id=<?php echo $book['book_id']; ?>" class="card rounded-0 shadow book-item text-reset text-decoration-none">
            <div class="img-holder overflow-hidden">
            <?php 
                        // Display the image directly using img tag
                        echo '<img src="' . $book["book_img"] . '" class="img-top" alt="Book Image">';
                    ?>
            </div>
            <div class="card-body">
              <div class="card-title fw-bolder h5 text-center"><?= htmlspecialchars($book['title']) ?></div>
            </div>
          </a>
      	</div>
        <?php
          $count++;
          if($count >= 4){
              $count = 0;
              break;
            }
          } ?> 
      </div>
<?php
      }
  if(isset($conn)) { mysqli_close($conn); }
  require_once "footer.php";
?>